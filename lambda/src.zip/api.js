const library = (function () {

    const apiKey = "c254b6df63fa7a5d5c947759de900b8e";

    return {
        apiKey: apiKey
    }

})();
module.exports = library;