const where = require('node-where');
const api = require('./api');
const kid = require('./kid');
const query = 'boston, massachusetts';

where.is(query, function(err, result) {
    if (result) {
      console.log('Address: ' + result.get('address'));
      console.log('Street Number: ' + result.get('streetNumber'));
      console.log('Street: ' + result.get('street'));
      console.log('Full Street: ' + result.get('streetAddress'));
      console.log('City: ' + result.get('city'));
      console.log('State / Region: ' + result.get('region'));
      console.log('State / Region Code: ' + result.get('regionCode'));
      console.log('Zip: ' + result.get('postalCode'));
      console.log('Country: ' + result.get('country'));
      console.log('Country Code: ' + result.get('countryCode'));
      console.log('Lat: ' + result.get('lat'));
      console.log('Lng: ' + result.get('lng'));
    }

    const city = result.get('city');
    const code = result.get('regionCode');

    const locationSlug = `${code}-${city}`.toLowerCase();
    console.log('locationSlug: ' + locationSlug);

    kid.getDoctors(locationSlug).then((res) => {
        const message = kid.processDoctors(query, res);
        console.log(message);
    }).catch((err) => {
        const message = `${err}, say another query.`;
        console.log(message);
    });

  });